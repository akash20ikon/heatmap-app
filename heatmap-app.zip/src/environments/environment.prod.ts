import { BrowserGlobalRef } from "src/app/core/globalRef/provider/global-reference.provider";

export const environment = {
  production: true,
  api: {
  },
};
