export interface IGlobalRef {
}
